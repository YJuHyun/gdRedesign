$( document ).ready( function() {
  $( '.mainMenuList' ).mouseenter( function() {
    $( this ).children('.menuInner').stop().slideDown(500);
  } );
  $( '.mainMenuList' ).mouseleave( function() {
    $( this ).children('.menuInner').stop().slideUp(500);
  } );
} );